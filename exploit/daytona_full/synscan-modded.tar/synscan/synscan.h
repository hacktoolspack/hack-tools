
/* define the number of child processes synscand will use */
#define MAXFORK 256

/* wether to enable support for X11 checking, disable on hosts without X libs installed */
/* #define X11CHECK 1 */
#undef X11CHECK

/* makes the status line be updated quicker, slows the scanning down but looks prettier */
#define FAST_STATUS

/* DO NOT MODIFY BELOW HERE!! */
/* Current version.. do not edit this! */
#define SYNSCAN_VERSION "3.0"
#define SPEC "The worm enabler!"

/* function prototypes */
char *rlookup (u_long sip);
char *nlookup (u_long sip);
char *ino (u_long sip);
int Connect (int fd, char *ip, unsigned int port, unsigned int time_out);
int write_timer (int fd, unsigned int time_out);
int read_timer (int fd, unsigned int time_out);
int is_samba (char *ip, unsigned long time_out, FILE * output);

/* defines */
#define ifc_buf ifc_ifcu.ifcu_buf
#define ifc_req ifc_ifcu.ifcu_req

