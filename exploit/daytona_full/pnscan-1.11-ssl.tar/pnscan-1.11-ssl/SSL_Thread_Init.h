#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
//#include <typedefs.h>
//#include <openssl/e_os.h>
#include <pthread.h>
#include <openssl/lhash.h>
#include <openssl/crypto.h>
#include <openssl/buffer.h>
#include <openssl/x509.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rand.h>

static pthread_mutex_t *lock_cs;
static long *lock_count;

#ifdef __cplusplus
extern "C" {
#endif
void SSL_thread_setup(void);
void SSL_thread_cleanup(void);
void SSL_pthreads_locking_callback(int mode, int type, char *file, int line);
unsigned long SSL_pthreads_thread_id(void);
#ifdef __cplusplus
}
#endif
